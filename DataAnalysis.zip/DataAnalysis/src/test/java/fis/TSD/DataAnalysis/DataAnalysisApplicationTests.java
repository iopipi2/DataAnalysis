package fis.TSD.DataAnalysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataAnalysisApplicationTests {

	@Test
	void contextLoads() {
	}

}
